
import React from 'react'

export const AddVideo = () => {
    return (
        <div className="add-video-form">
            <form action="">
                <input type="text"/>
            </form>
        </div>
    )
}
